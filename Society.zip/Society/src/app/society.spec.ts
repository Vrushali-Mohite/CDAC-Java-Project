import { Society } from './society';

describe('Society', () => {
  it('should create an instance', () => {
    expect(new Society()).toBeTruthy();
  });
});
