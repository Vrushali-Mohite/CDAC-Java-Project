import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flat-owner',
  templateUrl: './flat-owner.component.html',
  styleUrls: ['./flat-owner.component.css']
})
export class FlatOwnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
