export class Society {
    uId:number;
    fName:string;
    lName:string;
    email:string;
    password:string;
    mobNo:string;
    bDate:Date;
    memberNos:number;
    BlockNo:number;
    HouseNo:number;
    entryDate:Date;
    userRole:string;
    constructor()
    {
        
    }

}

