export class Event {
    eId:number;
    eSubject:string;
    eDescription:string;
    eOccation:string;
    eVenue:string;
    eDate:Date;
    eExpenditure:number;
    eStatus:boolean;
}
