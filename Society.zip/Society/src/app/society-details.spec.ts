import { SocietyDetails } from './society-details';

describe('SocietyDetails', () => {
  it('should create an instance', () => {
    expect(new SocietyDetails()).toBeTruthy();
  });
});
