export class SocietyDetails {
    sId:number;
    sName:string;
    address:string;
    city:string;
    pinCode:number;
    noOfHouses:number;
    status:boolean;
    EntryDate:string;   
}
