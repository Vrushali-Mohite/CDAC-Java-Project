import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sec-login-success',
  templateUrl: './sec-login-success.component.html',
  styleUrls: ['./sec-login-success.component.css']
})
export class SecLoginSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
